function downFile(fileMapPath, fileName)
{
  location.href = '/inc/download.asp?file=' + fileName + '&fileMapPath=' + fileMapPath;
}

window.onload = function()
{
  //Calendar Popup�� ���� iframe ���
  var oDiv = document.createElement("div");
  document.body.appendChild(oDiv);
	oDiv.innerHTML = "<div id=\"CalendarLayer\" style=\"display:none\">" 
								+ "<iframe name=\"CalendarFrame\" src=\"/js/cal/cal.html\" border=\"0\" frameborder=\"0\" scrolling=\"no\" width=\"175\" height=\"180\"></iframe>"
								+ "</div>"
								+ "<div id=\"MonthLayer\" style=\"display:none\">"
								+ "<iframe name=\"MonthFrame\" src=\"/js/cal/mon.html\" border=\"0\" frameborder=\"0\" scrolling=\"no\" width=\"175\" height=\"120\"></iframe>"
								+ "</div>";
}

function checkEssential()
{
  //�ʼ� �Է»��� üũ
	var essentialInput = $$('*[class="essential"]');

	for (i=0; i<essentialInput.length; i++)
	{
		if (essentialInput[i].value == "") 
		{
			alert("�ʼ��Է»���[" + essentialInput[i].title + "]��(��) �Է��ϼ���.");
			essentialInput[i].focus();
			return false;
		}
	}
	return true;
}

function resetFrm()
{
  $('frm').reset();
}

function saveFrm()
{
  var retCheckEssential;
  retCheckEssential = checkEssential();
  if (retCheckEssential == false)
  {
    return;
  }
  $('frm').submit();
}	

function delFrm(d_url)
{
  if(confirm("���� �����Ͻðڽ��ϱ�?"))
  {
    $('frm').action = d_url;
  	$('frm').submit();
  }  		
}			
	
function formSubmit(formName)
{
  var frm = $(formName);
  $('page').value = 1;
  frm.submit();
}

function saveOtherFrm(actionName){
  var retCheckEssential;
  retCheckEssential = checkEssential();
  if (retCheckEssential == false)
  {
    return;
  }
  $('frm').action = actionName;
	$('frm').submit();
}

function sendUrl(hUrl){
  location.href = hUrl;
}


if (window.event)
{
function enterCheck(formName) 
{ 
  if (window.event.keyCode == '13') 
  { 
  	formSubmit(formName); 
  } 
} 
}
else
{
function enterCheck(formName) 
{
  return; 
}  
}

function gotoPage(formName, page)
{
  var frm = $(formName)
  $('page').value = page;
  frm.submit();
}

function linkContent(h_url) 
{
  parent.rightframe.location.href = h_url;
} 

function linkLeftContent(h_url) 
{
  parent.leftframe.location.href = h_url;
} 
 
function reloadLeft() 
{
  parent.leftframe.location.reload();
} 
 

function checkFileSize(obj) 
{ 
  if (navigator.userAgent.indexOf('MSIE') > 0 && ((navigator.appVersion.indexOf('MSIE 7.') > 0) || (navigator.appVersion.indexOf('MSIE 8.') > 0)))
  {  
/*    var fso = new ActiveXObject("Scripting.FileSystemObject");
    var f = fso.GetFile(filename.value);
    var filesize = f.size;
    f = null;
    fso = null;*/
    return 0;
  }
  else
  {
    var img = new Image();
    img.dynsrc = obj.value;
    return img.fileSize; 
  }
}

function changeUnit(value)
{
   if(value > 1000000000000){
       return Math.floor(value / 10000000000)/100 + " TB";
   }else if(value> 1000000000){
       return Math.floor(value / 10000000)/100 + " GB";
   }else if(value> 1000000){
       return Math.floor(value / 10000)/100 + " MB";
   }else if(value> 1000){
       return Math.floor(value / 10)/100 + " KB";
   }else{
       return value + " Byte";
   }
}


/*
function checkFileSize (fileName) {
  if (document.layers) {
    if (navigator.javaEnabled()) {
      var file = new java.io.File(fileName);
      if (location.protocol.toLowerCase() != 'file:') {
        netscape.security.PrivilegeManager.enablePrivilege('UniversalFileRead');
   }
      return file.length();
    } else {
   return -1;
  }
  }
  else if (document.all) {
    window.oldOnError = window.onerror;
    window.onerror = function (err) {
      if (err.indexOf('utomation') != -1) {
        alert('file access not possible');
        return true;
      } else {
        return false;
   }
    }
    var fso = new ActiveXObject('Scripting.FileSystemObject');
    var file = fso.GetFile(fileName);
    window.onerror = window.oldOnError;
    return file.Size;
  }
}
*/

function checkFileType(fileName) 
{ 
  if (fileName.substr(fileName.length-3, fileName.length).toUpperCase()!= "JPG" && fileName.substr(fileName.length-3,fileName.length).toUpperCase()!= "GIF")
  {
    alert("JPG �Ǵ� GIF ������ ����ϼ���");
    return false;
	}
}    

/*function openWindow(wUrl, wName, wLeft, wTop, wWidth, wHeight)
{
	var wOption = "left=" + wLeft + ",top=" + wTop +",height=" + wHeight + ",width=" + wWidth +",location=no,menubar=no,resizable=no,scrollbars=no,status=no,toolbar=no";
	window.open(wUrl, wName, wOption);
}
*/

function openWindow(url, description, width,  height) 
{
   var screenPosX = screen.availWidth/2 - width/2; 
   var screenPosY = screen.availHeight/2 - height/2; 
   var features = "'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=no, top="+screenPosY+", left="+screenPosX+", width="+width+", height="+height+"'"; 
  
   var popupedWin = window.open(url, description, features); 
   popupedWin.focus();
} 

function setCookie (name, value, expires) 
{
	document.cookie = name + "=" + escape (value) + "; path=/; expires=" + expires.toGMTString();
}

function getCookie(Name) 
{
	var search = Name + "=";
	if (document.cookie.length > 0) // ��Ű�� �����Ǿ� �ִٸ� 
	{
		offset = document.cookie.indexOf(search);
		// ��Ű�� �����ϸ�
		if (offset != -1) 
		{
			offset += search.length;
			// set index of beginning of value
			end = document.cookie.indexOf(";", offset);
			// ��Ű ���� ������ ��ġ �ε��� ��ȣ ����
      if (end == -1)
      {
				end = document.cookie.length;
			}
			return unescape(document.cookie.substring(offset, end));
		}
	}
	return "";
}

function show_tr(tr_id) 
{
  var obj = $(tr_id).style;
  if (obj.display == "block") 
  {
    obj.display = "none";
  }
  else 
  {
    obj.display = "block";
  }
}

function wait(msecs)
{
  var start = new Date().getTime();
  var cur = start
  while(cur - start < msecs)
  {
    cur = new Date().getTime();
  }
} 


function check_fgnno(fgnno) {
        var sum=0;
        var odd=0;
        buf = new Array(13);
        for(i=0; i<13; i++) { buf[i]=parseInt(fgnno.charAt(i)); }
        odd = buf[7]*10 + buf[8];
        if(odd%2 != 0) { return false; }

//        if( (buf[11]!=6) && (buf[11]!=7) && (buf[11]!=8) && (buf[11]!=9) ) {
//                return false;
//        }

        multipliers = [2,3,4,5,6,7,8,9,2,3,4,5];
        for(i=0, sum=0; i<12; i++) { sum += (buf[i] *= multipliers[i]); }
        sum = 11 - (sum%11);
        if(sum >= 10) { sum -= 10; }
        sum += 2;
        if(sum >= 10) { sum -= 10; }
        if(sum != buf[12]) { return false }
        return true;
}
