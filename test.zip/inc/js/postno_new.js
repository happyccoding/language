$(document).ready(function () {

	$("#sido").change(function () {

		if ($(this).attr("value") == "") {
			$("#gugun").find("option").remove();
			$("#gugun").append("<option value=''>=== 시/군/구 ===</option>");
		}
		else {
			$.option("gugun", "시/군/구");
		}
	});

	 $("img#btn_close").click(function () {
		$.select_address();
	});

	$("img#find_zipcode").click(function () {
		$.search();
	});
});

$(function () {
	$.extend({
		//주소선택
		select_address: function () {                //우편번호와 주소 opener 전달
			if (opener) {

				if ($(':radio[name="zipcode"]').is(":checked") == false) {
					self.close();
					return;
				}

				var selectVal = $(':radio[name="zipcode"]:checked').val();
				var zipcode = selectVal.split('^')[0];
				var address = selectVal.split('^')[1];

				var f=opener.document.frmEmp;
				f.postno1.value=zipcode.split('-')[0];
				f.postno2.value=zipcode.split('-')[1];
				f.addr1.value=address;
				f.addr2.focus();
				window.close();
			}
		},
		//시도,시군구 select box option
		option: function (id, text) {
			var value = "";

			if (text == "시/군/구") {
				value = $("#sido").val();
				if (value == "" || value == null)
					return;
			}
			
			obj = $("#" + id);
			
			obj.find("option").remove();
			obj.css("background", "#fff url(/member/img/loader2.gif) no-repeat 80% 50%");
			obj.append("<option value=''>=== " + text + " ===</option>");
				
			var pars="func=SG&sido="+value;

			fnProc("/emp/postno_proc.asp",pars,"$.optResult(Msg, '"+id+"')");
				
		},
		optResult: function (result, id){
		  
  			$("#" + id).css("background", "");
  			$("#" + id).append(result);
		},
		
		//검색
		search: function () {

			if ($("#sido").val() == "") {
				alert("시/도를 선택하여 주십시요.");
				return;
			}
			if ($("#sido").val() != "세종특별자치시" && $("#gugun").val() == "") {
				alert("시/군/구를 선택하여 주십시요.");
				return;
			}
			if ($("#dong").val() == "") {
				alert("검색어를 입력하여 주십시요.");
				return;
			}


			$("#result").html("<ul><li class=\"nodata\"><img src=\"/member/img/loader.gif\" alt=\"로딩중\"  /></li></ul>");

			var sido = $("#sido").val();
			var gugun = $("#gugun").val();
			var dong = $("#dong").val();
			var pars="func=ZIP&sido="+sido+"&gugun="+gugun+"&dong="+dong;
			fnProc("/emp/postno_proc.asp",pars,"$.zipResult(Msg)");
		},

		zipResult: function(result){
			$("#result").html(result);
		},

		keyDown: function () {
			if (event.keyCode == 13) {
				$.search();
			}
		}
	});

  
	$.option("sido", "시/도");
	$.option("gugun", "시/군/구");

});

var isProc=0;
function fnProc(ProcFile,Pars,Func) {if (isProc==1) return; isProc=1;var myAjax=new Ajax.Request (ProcFile,{asynchronous:true,method:"post",parameters:Pars,onSuccess:function(request){isProc=0;var xmlDoc=request.responseXML;var Err=xmlDoc.getElementsByTagName("Err")[0].childNodes[0].nodeValue;var Msg = xmlDoc.getElementsByTagName("Msg")[0].childNodes[0].nodeValue;if(Err=="0"){eval(Func);}else if(Err=="1"){alert(Msg);}else if(Err=="9"){alert(Msg);location.reload();}else{isProc=0;alert("Request Failure");}},onFailure:function(){alert("에러가 발생했습니다.\n\n잠시후에 다시 이용해주세요.");}});}